package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    TextView tvInfo;
    EditText etInput;
    Button bControl;
    int rand = 1 + (int) (Math.random() * 100);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInfo = (TextView)findViewById(R.id.textView1);
        etInput = (EditText)findViewById(R.id.editText1);
        bControl = (Button)findViewById(R.id.button1);

    }
    public void onClick(View v){
        int a = Integer.parseInt(etInput.getText().toString());
        if (a>100 || a<1) {
            tvInfo.setText(getResources().getString(R.string.error));
        } else if (a<rand) {
            tvInfo.setText(getResources().getString(R.string.behind));
        } else if (a == rand) {
            tvInfo.setText(getResources().getString(R.string.hit));
        } else if (a>rand) {
            tvInfo.setText(getResources().getString(R.string.ahead));
        } else {
            tvInfo.setText(getResources().getString(R.string.error));
        }

    }
}